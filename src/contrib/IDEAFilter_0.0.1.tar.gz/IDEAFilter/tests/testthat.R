library(testthat)
library(shinyDataFilter)

test_check("shinyDataFilter")
