library(testthat)
library(profvis)

test_check("profvis")
